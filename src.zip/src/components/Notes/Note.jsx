import React from 'react'
import { useNote } from '../../context/NoteContext'
import { Link } from 'react-router-dom';

export default function Note() {
    const {activeNote,notes} = useNote();
    if(notes.length<=0){
      return (
        <div className="w-full h-screen flex flex-col items-center justify-center">
          <h1 className='text-3xl'>No notes yet!</h1>
          <Link to='addnote/' className='border border-blue-600 text-blue-600 duration-300 hover:bg-blue-600 hover:text-white/90 rounded-lg p-3 mt-2'>Create first Note</Link>
        </div>
      )
    }
  return (
    <div className='w-full h-screen p-3'>
      <h1 className='text-3xl'>{activeNote.title}</h1>
        <h3 className='text-xl'>{activeNote.folder}</h3>
        <p>{activeNote.content}</p>
    </div>
  )
}
